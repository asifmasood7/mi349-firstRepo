# boilerplate
Basic HTML and CSS setup for simple web design
